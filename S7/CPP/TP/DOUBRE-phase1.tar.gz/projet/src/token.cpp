#include <iostream>
using namespace std;

#include "token.h"

bool Token::isOperator(){
    return ((typetok==Type::plus) || (typetok==Type::minus) || (typetok==Type::mul) || (typetok==Type::div));
}

bool Token::isNumber(){
    return typetok==Type::number;
}

bool Token::isPar(){
    return ((typetok==Type::lp) || (typetok==Type::rp));
}

Type Token::getType(){
    return typetok;
}

char Token::getTypeVal(){
    switch (typetok)
    {
    case Type::plus :
        return '+';
        break;
    case Type::minus :
        return '-';
        break;
    case Type::mul :
        return '*';
        break;
    case Type::div :
        return '/';
        break;
    case Type::lp :
        return '(';
        break;
    case Type::rp :
        return ')';
        break; 
    default:
        break;
    }    
   return 'E';
}

double Token::getVal(){
    return valtok;
}

void Token::setVal(double dbl){
    valtok=dbl;
}

