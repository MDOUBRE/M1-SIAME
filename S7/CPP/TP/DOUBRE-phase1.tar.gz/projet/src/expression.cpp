#include <iostream>
using namespace std;
#include <list>

#include "expression.h"

double Expression::eval(){
    list<Token> pile;
    while(!(listRPN.empty())){
        if(listRPN.front().isNumber()){
            pile.push_back(listRPN.front());
            listRPN.pop_front();
        }
        else if(listRPN.front().isOperator()){
            double tmp1=pile.back().getVal();
            pile.pop_back();
            double tmp2=pile.back().getVal();
            double res=op(listRPN.front().getType(), tmp2, tmp1);
            pile.back().setVal(res);
            listRPN.pop_front();
        }
        else{
            listRPN.pop_front();
        }
    }
    return pile.back().getVal();
}

double Expression::op(Type type, double d1, double d2){
    if(type==Type::plus){
        return d1+d2;
    }
    else if(type==Type::minus){
        return d1-d2;
    }
    else if(type==Type::mul){
        return d1*d2;
    }
    else if(type==Type::div){
        return d1/d2;
    }
    else{
        return 0;
    }
}

void Expression::parse(){
    bool norm{true};
    for (Token tok:listTokExpr)
    {
        if(tok.isPar()){
            norm=false;
        }
    }
    if(norm==true){
        parseNorm();
    }
    else{
        parsePar();
    }        
}
// Token en RPN à partir d'expression sans paranthèses
void Expression::parseNorm(){
    list<Token> pile;
    for(Token tok:listTokExpr){
        if(tok.isNumber()){
            listRPN.push_back(tok);
        }
        else{
            if(tok.getType()==Type::mul || tok.getType()==Type::div){
                while(pile.back().getType()==Type::div || pile.back().getType()==Type::mul){
                    listRPN.push_back(pile.back());
                    pile.pop_back();
                }
                pile.push_back(tok);
            }
            else{
                while(!(pile.empty())){
                    listRPN.push_back(pile.back());
                    pile.pop_back();
                }
                pile.push_back(tok);
            }
        }
    }
    while(!(pile.empty())){
        listRPN.push_back(pile.back());
        pile.pop_back();
    }
}

// Token en RPN à partir d'expression avec paranthèses
void Expression::parsePar(){
    list<Token> pile;
    for(Token tok:listTokExpr){
        if(tok.isNumber()){
            listRPN.push_back(tok);
        }
        else if(tok.getType()==Type::lp){
            pile.push_back(tok);
        }
        else if(tok.getType()==Type::rp){
            while(pile.back().getType()!=Type::lp){
                listRPN.push_back(pile.back());
                pile.pop_back();
            }
            pile.pop_back();
        }
        else{
            if(pile.empty() || pile.back().getType()==Type::lp){
                pile.push_back(tok);
            }
            else if((tok.getType()==Type::mul || tok.getType()==Type::div) && (pile.back().getType()==Type::plus || pile.back().getType()==Type::minus)){
                pile.push_back(tok);    
            }
            else{
                listRPN.push_back(pile.back());
                pile.pop_back();
                pile.push_back(tok);
            }
        }
    }
    while(!(pile.empty())){
        listRPN.push_back(pile.back());
        pile.pop_back();
    }
}

void Expression::printRPN(){
    cout << endl << "Liste RPN des token triés pour evaluation : " << _expr << " :" << endl;
    for(Token tok: listRPN){
        if(tok.isNumber()){
            cout << "number(" << tok.getVal() << ")" << endl;
        }
        else if(tok.isOperator()){
            char ctmp{};
            ctmp=tok.getTypeVal();
            cout << "operator(" << ctmp << ")" << endl;
        }
        else if(tok.isPar()){
            char ctmp{};
            ctmp=tok.getTypeVal();
            cout << "operator('" << ctmp << "')" << endl;
        }
        else{
            cout << "Error" << endl;
        }
    }
}
