#include <list>
#include <sstream>
#include <iostream>
using namespace std;

#include "tokenstring.h"

void Tokenstring::print(){
    cout << endl << "Liste de token pour l'expression " << *_chaine << " :" << endl;
    for(Token tok: tokenString){
        if(tok.isNumber()){
            cout << "number(" << tok.getVal() << ")" << endl;
        }
        else if(tok.isOperator()){
            char ctmp{};
            ctmp=tok.getTypeVal();
            cout << "operator(" << ctmp << ")" << endl;
        }
        else{
            char ctmp{};
            ctmp=tok.getTypeVal();
            cout << "par('" << ctmp << "')" << endl;
        }
    }
}

void Tokenstring::listToken(){    
    for(char c: *_chaine){
        string strtmp{""};
        if(c!='1' && c!='2' && c!='3' && c!='4' && c!='5' && c!='6' && c!='7' && c!='8' && c!='9' && c!='0' && c!='.'){
            if(tmp.empty()==false){
                for(char car: tmp){
                    strtmp+=car;
                }
                double number;
                istringstream iss(strtmp);
                iss >> number;
                tokenString.push_back(Token{strtmp,Type::number,number});
            }
            strtmp="";
            while(!(tmp.empty())){
                tmp.pop_front();
            }
        }
        switch (c)
        {
        case '1' :
            tmp.push_back(c);
            break;
        case '2' :
            tmp.push_back(c);
            break;
        case '3' :
            tmp.push_back(c);
            break;
        case '4' :
            tmp.push_back(c);
            break;
        case '5' :
            tmp.push_back(c);
            break;
        case '6' :
            tmp.push_back(c);
            break;
        case '7' :
            tmp.push_back(c);
            break;
        case '8' :
            tmp.push_back(c);
            break;
        case '9' :
            tmp.push_back(c);
            break;
        case '0' :
            tmp.push_back(c);
            /*
            if(!(tmp.empty())){
                tmp.push_back(c);    
            }
            else{
                cout << "Error, un nombre entier ne peut pas commencer par 0" << endl;
            }
            */
            break;
        case '.' :
            tmp.push_back(c);
            break;
        case '+' :
            strtmp+=c;
            tokenString.push_back(Token{strtmp,Type::plus,0.0});
            break;
        case '-' :
            strtmp+=c;
            tokenString.push_back(Token{strtmp,Type::minus,0.0});
            break;
        case '*' :
            strtmp+=c;
            tokenString.push_back(Token{strtmp,Type::mul,0.0});
            break;
        case '/' :
            strtmp+=c;
            tokenString.push_back(Token{strtmp,Type::div,0.0});
            break;
        case '(' :
            strtmp+=c;
            tokenString.push_back(Token{strtmp,Type::lp,0.0});
            break;
        case ')' :
            strtmp+=c;
            tokenString.push_back(Token{strtmp,Type::rp,0.0});
            break;
       default:
            break;
        }
    }
    string strtmp{""};
    if(tmp.empty()==false){
        for(char car: tmp){
            strtmp+=car;
            
        }
        double number;
        istringstream iss(strtmp);
        iss >> number;
        tokenString.push_back(Token{strtmp,Type::number,number});
    }
    while(!(tmp.empty())){
        tmp.pop_front();
    }

}

int Tokenstring::sizeListTok(){
    return tokenString.size();
}

void Tokenstring::free(){
    while(!(tokenString.empty())){
        tokenString.pop_front();
    }
}

list<Token> Tokenstring::getListToken(){
    return tokenString;
}