#include <iostream>
#include <sstream>
#include <string>
#include <locale>
using namespace std;

#include "program.h"

#define N 100000000

// cette méthode boucle() sert à boucler et appeler la méthode 'analyse()'
// on l'appelle tant que l'utilisateur ne rnetre pas 'quitter'
void Program::boucle(){
    // ces deux booléens sert à stopper la boucle dans le cas ou analyse() envoie true
    bool tq{true};
    bool fin{false};
    while(tq){
        fin=analyse();
        if(fin==true){
            tq=false;
        }
        printMemory();
    }
    memory.clear();
}

// cette méthode 'analyse()' elle celle dans laquelle on traite les expressions de l'utilisateur
// elle renvoie un booléen qui détermine si on stop la boucle ou non
bool Program::analyse(){
    bool fin{false};
    locale loc;
    cout << endl << "Entrez expression arithmétique puis '$' à la ligne, ou 'quitter$' pour sortir du programme." << endl << endl;
    
    // on met dans le string expression ce que rentre l'util tant qu'on a pas de 'e'
    getline(cin,expression,'$');
    
    // on test si ce qu'à rentrer l'util n'est pas 'quitter'
    if(expression=="quitter"){
        fin=true;
    }    

    // sinon on traite 'expression'
    else{
        // on init uin nouveau string dont on va se servir pour créer les tokens
        string test_expr{""};

        // on boucle sur tous les caractères de 'expression'
        for(char c : expression){
            // si ce n'est pas un retour à la ligne aors on enfile dans 'test_expr'
            if(c!='\n'){
                test_expr.push_back(c);
            }
            // sinon on est arrivé à la fin d'une expression à traiter
            else{
                bool equal{false};
                bool alpha{false};
                for(char car : test_expr){
                    if(car=='='){
                        equal=true;
                    }
                    else if(isalpha(car,loc)){
                        alpha=true;
                    }
                }
                if(equal==true){
                    memo(test_expr);
                }
                else if (alpha==true && test_expr.back()!=';' && equal==false){
                    string tmp{""};  
                    string temporaire{""};           
                    for(char car : test_expr){
                        if(isalpha(car,loc)){
                            tmp.push_back(car);
                        }
                        else if(((car=='*') || (car=='/') || (car=='+') || (car=='-')) && (!(tmp.empty()))){
                            double tempo=memory.find(tmp)->second;
                            string temp=to_string(tempo);
                            for(char carac : temp){
                                temporaire.push_back(carac);
                            }
                            temporaire.push_back(car);
                            tmp="";
                        }
                        else{
                            temporaire.push_back(car);
                        }
                    }
                    if(!(tmp.empty())){
                        double tempo=memory.find(tmp)->second;
                        string temp=to_string(tempo);
                        for(char carac : temp){
                            temporaire.push_back(carac);
                        }
                        tmp="";
                    }
                    test_expr=temporaire;
                    Tokenstring tokstr{test_expr};
                    tokstr.listToken();

                    Expression expr{test_expr,tokstr.getListToken()};
                    expr.parse();
                    //expr.printRPN();

                    // on ajoute le résultat de l'expression à al lists des résultats
                    result.push_back(expr.eval());

                    // on libère l'espace de la liste des tokens
                    tokstr.free();                    
                }                                
                else if(test_expr.back()!=';'){
                    // on crée un objet Tokenstring et on fait la list des tokens à partir de l'expression
                    Tokenstring tokstr{test_expr};
                    tokstr.listToken();

                    // on passe cette liste dans un objet Expression dans lequel on va la parser
                    Expression expr{test_expr,tokstr.getListToken()};
                    expr.parse();
                    //expr.printRPN();

                    // on ajoute le résultat de l'expression à al lists des résultats
                    result.push_back(expr.eval());

                    // on libère l'espace de la liste des tokens
                    tokstr.free();
                    
                }
            // on remet bien le string à vide pour la prochaine expr de celles rentrées par l'util
            test_expr="";
            }   
        }
    }       
    // on finit de mettre dans le string expression les lettres qui auraient été rentrés après un e
    getline(cin,expression);
    // on vide le string expression pour le prochain appel à analyse()
    expression="";
    cout << endl;
    print();
    // on vide la liste des résultats
    while(!(result.empty())){
        result.pop_back();
    }
    // on retourne le booléen fin qui stop ou non la boucle
    return fin;
}

// Dans cette fonction on affiche les résultats
// ces résultats sont contenus dans la liste 'result'
// ce sont les résultats des expressions rentrés par l'utilisateur
void Program::print(){
    for(double res : result){
        cout << res << endl;
    }
}

void Program::memo(string expr){
    string nameVar{""};
    string expression{""};
    locale loc;
    int i{0};
    string tmp{""};
    // tq pas égal alors ca fait parti du nom de la variable
    while(expr[i]!='='){
        nameVar.push_back(expr[i]);
        i++;
    }
    i++;
    // on test si chiffre ou chaine de caractère
    // si chaine de caractère alors on va chercher dans la mam
    // la valeur correspondante à la chaine de caractère
    while(expr[i]!=';'){
        if(isalpha(expr[i],loc)){
            tmp.push_back(expr[i]);
        }
        else if(((expr[i]=='*') || (expr[i]=='/') || (expr[i]=='+') || (expr[i]=='-')) && (!(tmp.empty()))){
            double tempo=memory.find(tmp)->second;
            string temp=to_string(tempo);
            for(char c : temp){
                expression.push_back(c);
            }
            expression.push_back(expr[i]);
            tmp="";
        }
        else{
            expression.push_back(expr[i]);

        }
        i++;
    }
    if(!(tmp.empty())){
            double tempo=memory.find(tmp)->second;
            string temp=to_string(tempo);
            for(char c : temp){
                expression.push_back(c);
            }
        tmp="";
    }
    // on évalue l'expression afin de pouvoir associer la valeur au nom de la nouvelle variable
    Tokenstring tokstr{expression};
    tokstr.listToken();

    // on passe cette liste dans un objet Expression dans lequel on va la parser
    Expression express{expression,tokstr.getListToken()};
    express.parse();
    //expr.printRPN();

    // on insert dans la mémoire le nom avec sa valeur associée
    memory.insert(pair<string,double>(nameVar,express.eval()));
    // on libère l'espace de la liste des tokens
    tokstr.free();
}

void Program::printMemory(){
    map<string,double>::iterator it;
    cout << "----- MEMORY -----" << endl << endl;
    for(it=memory.begin(); it!=memory.end(); it++){
        cout << it->first << " = ";
        cout << it->second << endl;
    }
    cout << endl << "------------------" << endl;
}