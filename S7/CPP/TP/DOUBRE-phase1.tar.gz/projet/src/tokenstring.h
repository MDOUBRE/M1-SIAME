#include <iostream>
#include <list>

#include "token.h"

class Tokenstring{

public:
    Tokenstring();
    Tokenstring(std::string &str): _chaine{&str} {}
    Tokenstring(std::string *str): _chaine{str} {}

    // on modifie la string _chaine avec str passé en argument
    void setEntree(std::string &str) {
        _chaine=&str;
    }

    // on affiche la list de Token tokenString
    void print();

    // on traite l'expression _chaine afin d'obtenir notre liste de Token tokenString
    void listToken();

    // on renvoie la taille de la liste tokenString
    int sizeListTok();

    // on vide la liste tokenString
    void free();

    // on renvoie la list tokenString
    list<Token> getListToken();

private:
    // expression à évaluer
    std::string *_chaine;

    // liste de Token réalisé à partir de l'expression _chaine
    list<Token> tokenString;
    // liste de caractères temporaire utilisée dans les méthodes
    list<char> tmp;
};