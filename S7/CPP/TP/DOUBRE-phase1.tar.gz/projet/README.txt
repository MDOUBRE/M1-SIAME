DOUBRE Maxime - M1 SIAME - Compte Rendu Phase 1 TP CPP


Pour compiler le programme :
	- "make" à partir du dossier build
	- "./calc" pour lancer le programme
	

Au début, j'ai divisé le TP en trois parties principales :
	- diviser et transformer une chaine de caractères en Tokens
	- lister les tokens
	- réorganiser cette list de Tokens pour pouvoir les évaluer
	

Pour la première partie j'ai fait tout d'abord les Classes 'Token' et et 'Tokenstring'

Dans la classe 'Token' on crée des objets ayant une chaine de caractère, un Type et une valeur.
La chaine de caractères correspond au caractère de l'expression dans un premier temps puis à la chaine de caractère s'il y a fusion avec un autre token lors d'un calcul par exemple.
Le type peut contenir 'number', 'plus', 'minus', 'mul', 'div', '=', '(' ou ')'.
Il est assigné à la création d'un objet Token selon si sa valeur correpond à un chiffre, un opérateur ou une paranthès.
Cette classe contient trois constructeurs, un par défaut et deux qui prennent en arguments un string, un Type et une valeur (init à 0.0 si le type est différent de 'number').

On a 3 booléens :
	- 'isOperator()' qui renvoie true si le token a un type 'mul', 'div', 'plus' ou 'minus', false sinon.
	- 'isNummber()' qui renvoie true si le token a un type 'number', false sinon.
	- 'isPar()' qui renvoie true si le token a un type 'lp' ou 'rp', false sinon.
On se sert de ces trois booléens dans le traitement pour obtenir les listes de tokens (normale et RPN) ainsi que dans l'affichage de ces listes.
On a une méthode 'getType()' qui renvoie le type du token, une méthode 'getTypeVal()' qui renvoie la val correspondante au type, une 'getVal()' qui renvoie la valeur du token et une 'setVal()' qui prend en arguments un double et modifie valtok avec la valeur du double passé en arguments.


Dans la classe 'Tokenstring' on crée des objets ayant une string, une list de Token et une list de caractères
La string '_chaine' correspond à l'expression que l'on doit tokeniser, la list de Token 'tokenString' est celle dans laquelle on va placer les Token crées pour chaque caractère de la string précédente et la liste de caractères 'tmp' nous sert de string temporaire pendant la transformation de l'expression en liste de Token.
On a trois constructeurs, un par défaut et les deux autres qui prennent une string en argument qui sera notre membre privé '_chaine'.
On a 6 méthodes:
	- 'setEntree()' qui modifie la string '_chaine' en la remplacant par une string 'str' passée en paramètres
	- 'print()' qui affiche le contenu de notre liste de Token 'tokenString'
	- 'listToken()' qui tokenize notre expression '_chaine' en list de Token 'tokenString'
	- 'sizeListTok()' qui renvoie la taille de notre list 'tokenString'
	- 'free()' qui vide notre liste 'tokenString'
	- 'getListToken()' qui renvoie notre list de Token 'tokenString'
	
Méthode 'listToken()' :
Dans cette méthode on va parcourir notre string '_chaine'.
Pour chaque caractère :
	- Si on a un opérateur ou une paranthèse alors on va créer un Token avec en argument le caractère, un type 'plus', 'minus', 'mul', 'div', '(' ou 'rp' selon l'opérateur/paranthèse et une valeur 0.0. On va ajouter ce Token en queue de list tokenString.
	- Si c'est un chiffre ou un '.' pour virgule alors on va l'ajouter à la liste de caractères 'tmp' et quand on aura un opérateur/paranthèse et/ou alors quand on aura fini le parcours de notre expression '_chaine' alors on va tester si la liste tmp est vide et si elle ne l'est pas alors on a un double à l'intérieur.
On va mettre cette liste de caractères dans une string 'strtmp' qu'on va transformer en double.
Une fois tranformé en double on va créer un Token avec type='number' et valeur=double et on va l'ajouter en queue de liste tokenString.


Une fois cette première partie terminée on doit obtenir transformer notre liste de Token 'tokenString' en liste de Token propice à l'évaluation (RPN). J'ai crée pour ca une calsse Expression dans laquelle je traite ma liste tokenString afin d'obtenir la RPN et de l'évaluer.

Dans la classe Expression on crée des objets ayant une string '_expr', deux list de Token 'listTokExpr' et 'listRPN'.
La string '_expr' est l'expression rentrée par l'utilisateur, la list 'listTokExpr' est la liste de Token faite dans Tokenstring à partir de l'expression et la liste 'listRPN' est la liste de Token triée à partir de 'listTokExpr' de manière à pouvoir l'évaluer.
On a un constructeur qui prend en arguments une string qui est l'expression et une liste de Token qui est la liste faite dans Tokenstring à aprtir de l'expression.
On a 7 méthodes :
	- 'eval()' qui renvoie un double, le résultat de l'expression à partir de la liste 'listRPN'
	- 'op()' qui envoir une double, résultat d'opération entre deux double
	- 'parse()' qui test si l'expression a des paranthèses et appelle le bon parse pour l'expression
	- 'parseNorm()' qui traite la liste 'litTokExpr' te fait 'listRPN' si l'expression n'a pas de paranthèses
	- 'parsePar()' qui traite la liste 'litTokExpr' te fait 'listRPN' si l'expression a des paranthèses
	- 'printRPN()' qui affiche la liste de Token 'listRPN'

Méthode 'parsePar()' :
Dans cette méthode on parcours la liste de Token 'listTokExpr'.
Si le token est un 'number' alors on le met en queue de liste 'listRPN'.
Sinon si on a unb 'lp' alors on empile sur 'pile'
Sinon si on a un 'rp' alors on dépile et met dans 'liRPN' tq tête de pile différente de 'lp'. On dépile aussi 'lp' mais on ne le met pas dans 'listRPN'.
Sinon si on a un 'operator' alors selon les priorités on empile et/ou dépile et met dans 'listRPN' la tête de pile avant si on est inférieur ou égal en priorité à l'opérateur en tête de pile.
Une fois le parcours de la liste 'listTokExpr' terminé on test si notre 'pile' est vide et si ce n'est pas le cas alors on dépile et ajoute à 'listRPN' jusqu'à ce qu'elle soit vide.

Méthode 'eval()' :
Dans cette méthode on parcours la liste 'listRPN'.
Si le token est un 'number' alors on empile sur 'pile' et on enlève la première valeur de la liste 'listRPN'
Si c'est un opérateur alors on dépile la tête, on prend la valeur de la nouvelle tête de pile et on fais l'opération en appelant la méthode 'op()'. On lui passe en argument la valeur du token que l'on a dépilé, la valeur de la nouvelle tête de pile et le type de l'opérateur lu dans 'listRPN'.
'op()' nous renvoie le résultat de l'opération sur les deux doubles passés en argument et on modifie la valeur de tête de pile pour y mettre la valeur obtenue avec le 'op()'.
A la fin il ne nous reste plus qu'un Token dans la pile et sa valeur est le résultat de l'évaluation de l'expression rentrée par l'utilisateur.
On la retourne donc.


Pour finir il fallait ajouter les suites d'expressions ainsi qu'une mémoire à notre programme.
Pour se faire j'ai crée une classe Program qui prend en arguments l'entrée standard istream, une liste de double qui contient le résultats des expressions, une string 'expression' qui contient tout ce que rentre l'utilisateur et une map 'memory' qui contient les variables déclarées et leurs valeurs.
On a deux constructeurs qui prennent en entrée un istream.
On a 5 méthodes :
	- 'boucle()' qui ne fait que boucler, appeler l'analyse et afficher la mémoire
	- 'analyse()' qui traite les expressions rentrées par l'utilisateur et fait ce qu'il faut selon l'expression sur la ligne
	- 'print()' qui affiche les résultats des expressions rentrées par l'utilisateur
	- 'memo()' qui gère la déclaration de nouvelles variables. Elle les met avec leurs valeurs dans la map 'memory'
	- 'printMemory()' qui affiche la mémoire, donc cahque nom de variable avec sa valeur associée
	
Méthode 'analyse()' :
On demande au début àl'utilisateur de rentrer une ou plusieurs expression en finissant par un saut à la ligne et un '$'.
On lit sur l'entrée standard ce qu'a entré l'util et on le met dans la string expression.
on test si l'utilisateur a rentré 'quitter$' et si c'est le cas alors fin de programme.
Sinon on va parcourir la string expression caractère / caractère et ligne / ligne.
Pour chaque ligne on va mettre tous les caractères de la ligne dans test_expr.

A partir de cette string test_expr on test sur tous les caractères si on a un égal et au moins une lettre dans l'expression.
Si on a un égal alors on appelle memo(test_expr) car ca veut dire qu'on crée une nouvelle variable, donc à mettre en mémoire.
Si pas d'égal mais au moins une lettre et qu'on a pas de ; à la fin de test_expr alors on traite la ligne comme une expression.
Donc on va mettre les lettres dans une string tmp jusqu'à avoir un opérateur ou arriver à la fin.
Si on a un opérateur ou qu'on arrive à la fin et que tmp n'est pas vide alors on va chercher dans map la valeur associée au nom de variable contenu dans tmp et on va la mettre dans la string 'temporaire' avec à la suite l'opérateur.
Si on a chiffre alors on met directement dans 'temporaire'.
Une fois le traitement de la ligne terminé, on va mettre 'test_expr'='temporaire' et on va crée un Tokenstring init avec la chaine de caractère 'test_expr'.
On va appeler .listToken() dessus puis on va mettre cette liste dans un objet Expression expr.
Dans cette expression on va parser la liste de Token pour obtenir la liste RPN puis on va l'évaluer.
Après ca on obtient un résultat que l'on va ajouter à la liste des résultats.

Une fois toutes les lignes traitées, on va free le TokenString, on va mettre 'test_expr' ainsi que 'expression' à vide et on apelle 'print()' afin d'afficher la liste des résultats.
Après ca on la vide pour pouvoir mettre les résultats des prochaines expressions rentrées par l'utilisateur.



Concernant les faiblesses de mon programme :
	- Il faut terminer par un saut à la ligne et un '$' pour finir de rentrer des expressions et que ca les traite. Ce n'est pas très bien fait, on devrait pouvoir faire un simple retour à la ligne en plus.
	- je ne gère pas les cas comme 5*(-4) donc le calcul avec des membres négatifs mais je ne crois pas que ce soit demandé
	- Je ne gère pas les espaces dans les déclarations nouvelles variables. il faut forcément faire ID= et pas ID = sinon le nom de la variable sera déclarée avec un " " dans la map et on n'arrivera pas à l'appeler pour avoir sa valeur.
	
	
DOUBRE Maxime
M1 SIAME						
